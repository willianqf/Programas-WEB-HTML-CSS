package com.api.ControleDeEstacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleDeEstacionamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleDeEstacionamentoApplication.class, args);
	}

}
